# Handling Execution Overruns - Overleaf Project

This folder is ready to upload to Overleaf as a ZIP archive.

## Main files
- `main.tex` - editable IEEE conference-style seminar paper draft
- `references.bib` - BibTeX database with relationship notes
- `figures/` - selected experiment plots
- `data/` - CSV results from the prototype
- `uppaal/overrun_model.xml` - small UPPAAL model of the main handling concept

## Compile on Overleaf
1. Upload the ZIP as a new project.
2. Set `main.tex` as the main document if Overleaf does not do so automatically.
3. Use pdfLaTeX. Overleaf will run Biber automatically; locally use:
   ```
   pdflatex main.tex
   biber main
   pdflatex main.tex
   pdflatex main.tex
   ```

## Important scientific wording
- The Python/OpenCV measurements are workload measurements, not certified WCET values.
- The `OverrunHandled` plots are a scheduling simulation, not a kernel-level CBS or CBShd implementation.
- The conceptual CPU-allocation figure is an explanatory diagram, not an exact scheduler trace.
- The 500 Hz value is a nominal release frequency derived from a 2 ms period, not a guaranteed fresh-result rate.

## Editing
Search for `EDITABLE METADATA` near the top of `main.tex` to change title and author information.
The GitHub URL is included as a footnote and can be changed directly in `main.tex`.

## Source PDFs
The copyrighted reference PDFs are deliberately not included in this ZIP. Their bibliographic entries are in `references.bib`.

# Handling Execution Overruns — Overleaf Package

Upload this ZIP file directly to Overleaf as a new project.

Main file:
- `main.tex`

Included:
- `references.bib` — bibliography database
- `figures/` — generated plots from the prototype
- `data/` — runtime CSV files and summary JSON
- `implementation/` — Python scripts used for the prototype

To compile in Overleaf:
1. Set `main.tex` as the main file.
2. Compile with pdfLaTeX.
3. If references do not appear on the first compile, press Recompile again.

The implementation is an educational simulation, not a kernel-level implementation of CBS or CBShd.
